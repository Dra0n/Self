module.exports = async (client) => {
  let array = [

    {
      name: "free",
      description: "free self leveling.",
      
    },
 



 
  ];
  await client.application.commands.set(array);
}